#ifndef CUSTOMFUNCTIONS_H
#define CUSTOMFUNCTIONS_H

void platzhalter(){
    // Dies ist nur ein Platzhalter.
}






#endif