#ifndef CUSTOMCONFIG_H
#define CUSTOMCONFIG_H

int pl_halter = 0;

#endif